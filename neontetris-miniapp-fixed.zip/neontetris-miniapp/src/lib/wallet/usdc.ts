import { parseUnits } from 'viem';

/** Native USDC on Base mainnet (6 decimals). Override in .env if needed. */
export const USDC_ADDRESS = (process.env.NEXT_PUBLIC_USDC_ADDRESS ??
  '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913') as `0x${string}`;

export const USDC_DECIMALS = 6;

export const TREASURY_ADDRESS = (process.env.NEXT_PUBLIC_TREASURY_ADDRESS ??
  '0x0000000000000000000000000000000000dEaD') as `0x${string}`;

export const GAME_FEE_USDC = Number(process.env.NEXT_PUBLIC_GAME_FEE_USDC ?? '0.1');

export const GAME_FEE_BASE_UNITS = parseUnits(
  GAME_FEE_USDC.toString(),
  USDC_DECIMALS
);

/** Minimal ERC-20 ABI — only what NeonTetris needs (transfer + balance + decimals). */
export const ERC20_ABI = [
  {
    type: 'function',
    name: 'transfer',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'to', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
  {
    type: 'function',
    name: 'balanceOf',
    stateMutability: 'view',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    type: 'function',
    name: 'decimals',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'uint8' }],
  },
] as const;

export function usdcToBaseUnits(amount: number): bigint {
  return parseUnits(amount.toString(), USDC_DECIMALS);
}

export function baseUnitsToUsdc(amount: bigint): number {
  return Number(amount) / 10 ** USDC_DECIMALS;
}
