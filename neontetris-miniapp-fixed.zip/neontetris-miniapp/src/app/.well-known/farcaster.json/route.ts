import { NextResponse } from 'next/server';

/**
 * Farcaster Mini App manifest, served at /.well-known/farcaster.json.
 * `accountAssociation` values come from signing your domain in the
 * Farcaster developer portal (Warpcast > Settings > Developer) — paste
 * the resulting header/payload/signature into your .env as FARCASTER_*.
 */
export async function GET() {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? 'https://neontetris.example.com';

  return NextResponse.json({
    accountAssociation: {
      header: process.env.FARCASTER_HEADER ?? '',
      payload: process.env.FARCASTER_PAYLOAD ?? '',
      signature: process.env.FARCASTER_SIGNATURE ?? '',
    },
    miniapp: {
      version: '1',
      name: 'NeonTetris',
      iconUrl: `${appUrl}/icon.png`,
      homeUrl: appUrl,
      imageUrl: `${appUrl}/embed-image.png`,
      buttonTitle: '🕹️ Play NeonTetris',
      splashImageUrl: `${appUrl}/splash.png`,
      splashBackgroundColor: '#05020a',
      webhookUrl: `${appUrl}/api/webhook`,
      subtitle: 'Pay-to-play neon Tetris',
      description:
        'Pay 0.1 USDC per game, climb the leaderboard, unlock neon skins, tip other players, and stake USDC in 1v1 duels — all from your Farcaster wallet on Base.',
      primaryCategory: 'games',
      tags: ['tetris', 'game', 'usdc', 'base', 'pvp'],
    },
  });
}
